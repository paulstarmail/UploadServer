#!./bin/python3

# The only argument is the desired port number.

from flask import Flask, render_template
from flask_wtf import FlaskForm
from wtforms import FileField, SubmitField
from werkzeug.utils import secure_filename
import os
import sys
import socket
import subprocess
from subprocess import check_output
from wtforms.validators import InputRequired

try:
	port_number = str(sys.argv[1])
except:
	sys.exit("No port provided!")
ip_address = check_output(['hostname', '--all-ip-addresses'])
ip_address = ip_address.decode("utf-8").strip()

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret'
app.config['UPLOAD_FOLDER'] = 'files'

class UploadFileForm(FlaskForm):
    file = FileField("File", validators=[InputRequired()])
    submit = SubmitField("Upload File")

@app.route('/', methods=['GET',"POST"])
@app.route('/home', methods=['GET',"POST"])
def home():
    form = UploadFileForm()
    if form.validate_on_submit():
        file = form.file.data # First grab the file
        file.save(os.path.join(os.path.abspath(os.path.dirname(__file__)),app.config['UPLOAD_FOLDER'],secure_filename(file.filename))) # Then save the file
        return "File has been successfully uploaded."
    return render_template('index.html', form=form)

if __name__ == '__main__':
    app.run(host=ip_address, port=port_number, debug=True)
